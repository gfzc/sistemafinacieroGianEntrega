package com.ciclo3.sistemafinanciero.model;

public enum EnumRole {
    Admin, Operario
}
