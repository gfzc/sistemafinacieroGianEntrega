package com.ciclo3.sistemafinanciero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemafinancieroApplicationTests {

    @Test
    void contextLoads() {
    }

}
